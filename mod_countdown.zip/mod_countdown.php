<?php
defined('_JEXEC') or die;

// Load template
require JModuleHelper::getLayoutPath('mod_countdown', $params->get('layout', 'default'));