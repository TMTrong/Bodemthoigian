<?php
defined('_JEXEC') or die;
// Không cần xử lý server-side trong trường hợp này